import datetime as dt
import math
from io import StringIO

import pandas as pd
import requests
import streamlit as st

st.set_page_config(page_title="Daily HR Predictor", page_icon="⚾", layout="wide")

TEAM_ABBR = {
    "Arizona Diamondbacks": "ARI", "Atlanta Braves": "ATL", "Baltimore Orioles": "BAL", "Boston Red Sox": "BOS",
    "Chicago Cubs": "CHC", "Chicago White Sox": "CWS", "Cincinnati Reds": "CIN", "Cleveland Guardians": "CLE",
    "Colorado Rockies": "COL", "Detroit Tigers": "DET", "Houston Astros": "HOU", "Kansas City Royals": "KC",
    "Los Angeles Angels": "LAA", "Los Angeles Dodgers": "LAD", "Miami Marlins": "MIA", "Milwaukee Brewers": "MIL",
    "Minnesota Twins": "MIN", "New York Mets": "NYM", "New York Yankees": "NYY", "Athletics": "ATH",
    "Philadelphia Phillies": "PHI", "Pittsburgh Pirates": "PIT", "San Diego Padres": "SD", "San Francisco Giants": "SF",
    "Seattle Mariners": "SEA", "St. Louis Cardinals": "STL", "Tampa Bay Rays": "TB", "Texas Rangers": "TEX",
    "Toronto Blue Jays": "TOR", "Washington Nationals": "WSH",
}

PARK_FACTORS = {
    "Coors Field": 1.25, "Great American Ball Park": 1.15, "Yankee Stadium": 1.12,
    "Citizens Bank Park": 1.10, "Dodger Stadium": 1.04, "Fenway Park": 1.03,
    "Globe Life Field": 1.02, "Wrigley Field": 1.00, "Truist Park": 1.00,
    "Camden Yards": 0.99, "T-Mobile Park": 0.94, "Oracle Park": 0.90, "Comerica Park": 0.88,
}

REQUIRED_COLS = ["player", "team", "barrel_pct", "hardhit_pct", "flyball_pct", "hr_per_pa"]
OPTIONAL_COLS = ["throws_split_bonus", "bat_order"]

@st.cache_data(ttl=900)
def get_schedule(date_str):
    url = "https://statsapi.mlb.com/api/v1/schedule"
    params = {"sportId": 1, "date": date_str, "hydrate": "probablePitcher"}
    r = requests.get(url, params=params, timeout=20)
    r.raise_for_status()
    data = r.json()
    games = []
    for d in data.get("dates", []):
        for g in d.get("games", []):
            teams = g.get("teams", {})
            away = teams.get("away", {})
            home = teams.get("home", {})
            venue = g.get("venue", {}).get("name", "Unknown")
            away_team = away.get("team", {}).get("name", "")
            home_team = home.get("team", {}).get("name", "")
            games.append({
                "gamePk": g.get("gamePk"),
                "game_time": g.get("gameDate", ""),
                "away": TEAM_ABBR.get(away_team, away_team),
                "home": TEAM_ABBR.get(home_team, home_team),
                "away_full": away_team,
                "home_full": home_team,
                "away_probable_pitcher": away.get("probablePitcher", {}).get("fullName", "TBD"),
                "home_probable_pitcher": home.get("probablePitcher", {}).get("fullName", "TBD"),
                "venue": venue,
                "park_factor": PARK_FACTORS.get(venue, 1.00),
                "status": g.get("status", {}).get("detailedState", ""),
            })
    return pd.DataFrame(games)

def sample_hitters():
    return pd.DataFrame([
        {"player":"Aaron Judge","team":"NYY","barrel_pct":26.0,"hardhit_pct":60.0,"flyball_pct":38.0,"hr_per_pa":0.085,"throws_split_bonus":0.02,"bat_order":2},
        {"player":"Shohei Ohtani","team":"LAD","barrel_pct":22.0,"hardhit_pct":55.0,"flyball_pct":37.0,"hr_per_pa":0.075,"throws_split_bonus":0.01,"bat_order":1},
        {"player":"Kyle Schwarber","team":"PHI","barrel_pct":19.0,"hardhit_pct":52.0,"flyball_pct":45.0,"hr_per_pa":0.070,"throws_split_bonus":0.01,"bat_order":1},
        {"player":"Julio Rodriguez","team":"SEA","barrel_pct":13.0,"hardhit_pct":50.0,"flyball_pct":31.0,"hr_per_pa":0.045,"throws_split_bonus":0.00,"bat_order":2},
        {"player":"Pete Crow-Armstrong","team":"CHC","barrel_pct":12.0,"hardhit_pct":45.0,"flyball_pct":36.0,"hr_per_pa":0.042,"throws_split_bonus":0.00,"bat_order":3},
    ])

def score_hitters(hitters, schedule, temp_f=75, wind_out_mph=0):
    games = []
    for _, row in schedule.iterrows():
        games.append({"team": row["away"], "opponent": row["home"], "probable_pitcher": row["home_probable_pitcher"], "venue": row["venue"], "park_factor": row["park_factor"], "home_away":"Away"})
        games.append({"team": row["home"], "opponent": row["away"], "probable_pitcher": row["away_probable_pitcher"], "venue": row["venue"], "park_factor": row["park_factor"], "home_away":"Home"})
    game_df = pd.DataFrame(games)
    df = hitters.copy()
    df.columns = [c.strip().lower() for c in df.columns]
    for col in REQUIRED_COLS:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")
    for col in OPTIONAL_COLS:
        if col not in df.columns:
            df[col] = 0
    merged = df.merge(game_df, on="team", how="inner")
    if merged.empty:
        return merged
    temp_boost = max(min((temp_f - 70) * 0.002, 0.04), -0.04)
    wind_boost = max(min(wind_out_mph * 0.004, 0.06), -0.03)
    # Simple calibrated starter model. Replace with trained coefficients later.
    raw = (
        0.025
        + merged["hr_per_pa"].astype(float) * 0.95
        + (merged["barrel_pct"].astype(float) / 100) * 0.12
        + (merged["hardhit_pct"].astype(float) / 100) * 0.035
        + (merged["flyball_pct"].astype(float) / 100) * 0.025
        + merged["throws_split_bonus"].astype(float)
    )
    order_bonus = merged["bat_order"].apply(lambda x: 0.012 if pd.notna(x) and 1 <= float(x) <= 4 else 0)
    prob = (raw + order_bonus + temp_boost + wind_boost) * merged["park_factor"].astype(float)
    merged["hr_probability"] = prob.clip(0.01, 0.18)
    merged["hr_%"] = (merged["hr_probability"] * 100).round(1)
    merged["grade"] = pd.cut(merged["hr_probability"], bins=[0, .045, .065, .085, .105, 1], labels=["C", "B-", "B", "A-", "A"])
    return merged.sort_values("hr_probability", ascending=False)

st.title("⚾ Daily Home Run Predictor")
st.caption("Starter model: ranks hitters playing today. Use for research, not guaranteed bets.")

with st.sidebar:
    st.header("Update Today")
    date = st.date_input("Game date", dt.date.today())
    temp_f = st.slider("Average game temp °F", 40, 105, 75)
    wind_out = st.slider("Wind blowing out mph", -10, 25, 0, help="Use negative if wind is blowing in.")
    st.markdown("### Hitter Stats Upload")
    st.write("CSV columns needed: player, team, barrel_pct, hardhit_pct, flyball_pct, hr_per_pa")
    uploaded = st.file_uploader("Upload hitter_stats.csv", type=["csv"])
    use_sample = st.checkbox("Use sample hitters", value=True)

try:
    schedule = get_schedule(date.strftime("%Y-%m-%d"))
    if schedule.empty:
        st.warning("No MLB games found for this date.")
        st.stop()

    st.subheader("Today's Games")
    st.dataframe(schedule[["away", "home", "away_probable_pitcher", "home_probable_pitcher", "venue", "status"]], use_container_width=True)

    if uploaded is not None:
        hitters = pd.read_csv(uploaded)
    elif use_sample:
        hitters = sample_hitters()
    else:
        st.info("Upload a hitter stats CSV or turn on sample hitters.")
        st.stop()

    ranked = score_hitters(hitters, schedule, temp_f=temp_f, wind_out_mph=wind_out)
    st.subheader("Top 10 HR Candidates")
    if ranked.empty:
        st.warning("Your hitter file loaded, but none of those teams are on today's schedule. Check team abbreviations like NYY, LAD, PHI.")
    else:
        top = ranked[["player", "team", "opponent", "home_away", "probable_pitcher", "venue", "hr_%", "grade"]].head(10)
        st.dataframe(top, hide_index=True, use_container_width=True)
        csv = ranked.to_csv(index=False).encode("utf-8")
        st.download_button("Download full rankings CSV", csv, f"hr_rankings_{date}.csv", "text/csv")

    with st.expander("Download sample hitter CSV format"):
        sample_csv = sample_hitters().to_csv(index=False)
        st.code(sample_csv, language="csv")
        st.download_button("Download sample CSV", sample_csv, "hitter_stats_sample.csv", "text/csv")

except Exception as e:
    st.error(f"Something went wrong: {e}")
    st.write("Check your internet connection and CSV column names.")
