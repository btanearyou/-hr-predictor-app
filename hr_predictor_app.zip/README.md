# Daily HR Predictor App

Phone-friendly Streamlit app for ranking today's home run candidates.

## What it does
- Pulls today's MLB schedule from the public MLB Stats API.
- Shows probable pitchers when available.
- Lets you upload hitter stats.
- Scores hitters and displays a Top 10 HR candidate list.

## Required CSV columns
`player, team, barrel_pct, hardhit_pct, flyball_pct, hr_per_pa`

Optional:
`throws_split_bonus, bat_order`

Team abbreviations should look like: NYY, LAD, PHI, SEA, CHC.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Make it phone-friendly
Deploy it on Streamlit Community Cloud, Render, or Replit. Once deployed, open the app link on your phone.

## Important
This is a starter scoring model, not a guaranteed betting model. Home runs are rare, so even top candidates usually miss most of the time.
